/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solvers;

/**
 *
 * @author Madero Padero
 */
public class GeneticSolver {
    //select libraries worth of n days
    //library sequence - elements in random order
    //within each library - >get random elements to send worth of the remaining days
    //select books worth of n days
//    
//    while(remainingDays>0){
//        random_library with books to send assigned
//                
//    
//    
//    
//    }
//    
    
//    public void createPopulation(){
//        
//    }
//    public void doMatingSeason(){
//        
//    }
}
